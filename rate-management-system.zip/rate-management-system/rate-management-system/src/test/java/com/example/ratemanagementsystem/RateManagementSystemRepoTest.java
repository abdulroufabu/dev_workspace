package com.example.ratemanagementsystem;
import static org.assertj.core.api.Java6Assertions.assertThat;

import java.text.ParseException;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.example.ratemanagementsystem.model.Rate;
import com.example.ratemanagementsystem.repo.RateManagementSystemRepo;
import com.example.ratemanagementsystem.util.DateUtil;

@ExtendWith(MockitoExtension.class)
@DataJpaTest
public class RateManagementSystemRepoTest {
    @Autowired
    private RateManagementSystemRepo rmsRepository;

    @BeforeEach
    void initUseCase() {
    	List<Rate> rates = null;
		try {
			rates = Arrays.asList(
			        new Rate(DateUtil.getDateFromISODate("2021-05-22"), DateUtil.getDateFromISODate("2021-05-22"), 30, "test")
			);
		} catch (ParseException e) {
			e.printStackTrace();
		}
        rmsRepository.saveAll(rates);
    }

    @AfterEach
    public void destroyAll(){
        rmsRepository.deleteAll();
    }

    @Test
    void saveAll_success() {
        List<Rate> rates = null;
		try {
			rates = Arrays.asList(
					new Rate(DateUtil.getDateFromISODate("2021-04-22"), DateUtil.getDateFromISODate("2021-05-22"), 50, "test1"),
					new Rate(DateUtil.getDateFromISODate("2021-06-22"), DateUtil.getDateFromISODate("2021-06-22"), 60, "test2"),
					new Rate(DateUtil.getDateFromISODate("2021-07-22"), DateUtil.getDateFromISODate("2021-07-22"), 70, "test3")
			);
		} catch (ParseException e) {
			e.printStackTrace();
		}
        Iterable<Rate> allRate = rmsRepository.saveAll(rates);

        AtomicInteger validIdFound = new AtomicInteger();
        allRate.forEach(rate -> {
            if(rate.getRateId()>0){
                validIdFound.getAndIncrement();
            }
        });

        assertThat(validIdFound.intValue()).isEqualTo(3);
    }

    @Test
    void findAll_success() {
        List<Rate> allRate = rmsRepository.findAll();
        assertThat(allRate.size()).isGreaterThanOrEqualTo(1);
    }
}