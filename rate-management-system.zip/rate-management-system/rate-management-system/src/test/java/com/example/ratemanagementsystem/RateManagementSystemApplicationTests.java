package com.example.ratemanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RateManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
