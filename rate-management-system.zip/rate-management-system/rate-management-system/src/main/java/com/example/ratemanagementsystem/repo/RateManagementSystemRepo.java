package com.example.ratemanagementsystem.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ratemanagementsystem.model.Rate;

public interface RateManagementSystemRepo extends JpaRepository<Rate, Long> {

	Optional<Rate> findByRateId(Long rateId);
	
}

