package com.example.ratemanagementsystem.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;
import javax.persistence.GeneratedValue;

@Entity
@Table(name = "Rate")
public class Rate implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "rate_Id", nullable = false, updatable = false)
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private Long rateId;

	@Column(name = "rate_description")
	private String rateDescription;

	@Column(name = "rate_effective_date", nullable = false)
	@Temporal(TemporalType.DATE)
	private Date rateEffectiveDate;

	@Column(name = "rate_expiration_date", nullable = false)
	@Temporal(TemporalType.DATE)
	private Date rateExpirationDate;

	@Column(name = "amount", nullable = false)
	private Integer amount;
	
	public Rate() {
		super();
	}
			
	public Rate(Date rateEffectiveDate, Date rateExpirationDate, Integer amount, String rateDesc) {
		super();
		this.rateEffectiveDate = rateEffectiveDate;
		this.rateExpirationDate = rateExpirationDate;
		this.amount = amount;
		this.rateDescription = rateDesc;
	}

	public Long getRateId() {
		return rateId;
	}

	public void setRateId(Long rateId) {
		this.rateId = rateId;
	}

	public String getRateDescription() {
		return rateDescription;
	}

	public void setRateDescription(String rateDescription) {
		this.rateDescription = rateDescription;
	}

	public Date getRateEffectiveDate() {
		return rateEffectiveDate;
	}

	public void setRateEffectiveDate(Date rateEffectiveDate) {
		this.rateEffectiveDate = rateEffectiveDate;
	}

	public Date getRateExpirationDate() {
		return rateExpirationDate;
	}

	public void setRateExpirationDate(Date rateExpirationDate) {
		this.rateExpirationDate = rateExpirationDate;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Rate [rateId=" + rateId + ", rateDescription=" + rateDescription + ", rateEffectiveDate="
				+ rateEffectiveDate + ", rateExpirationDate=" + rateExpirationDate + ", amount=" + amount + "]";
	}

}
