package com.example.ratemanagementsystem.util;

public class RateUtils {
	
	public static final String surchargeUri = "https://surcharge.free.beeceptor.com/surcharge";
	
}
