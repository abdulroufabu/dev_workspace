package com.example.ratemanagementsystem.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 * Utilities that will be used to manipulate, process or format data 
 * 
 */
public class DateUtil {
	
	/**
	 * ISO date format pattern (yyyy-MM-dd)
	 * 
	 */
	private static String DATE_PRECISION = "yyyy-MM-dd";

    
    /**
     * Formating date object to ISO date format String 
     * 
     * @param date Date object
     * @return String represent ISO date formated 
     */
    public static String getISODate(Date date) {
    	if(date != null){
    		SimpleDateFormat formaterISO = new SimpleDateFormat(DATE_PRECISION);
        	return formaterISO.format(date);
    	}
    	return "";
    }
    
    public static Date getDateFromISODate(String date) throws ParseException {
    	if(date != null){
    		SimpleDateFormat formaterISO = new SimpleDateFormat(DATE_PRECISION);
    		Date dateNew = formaterISO.parse(date);
        	return dateNew;
    	}
    	return null;
    }
}
