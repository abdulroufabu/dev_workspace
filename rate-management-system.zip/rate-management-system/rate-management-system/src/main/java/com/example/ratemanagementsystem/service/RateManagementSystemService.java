package com.example.ratemanagementsystem.service;

import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.example.ratemanagementsystem.exception.ApiInternalErrorException;
import com.example.ratemanagementsystem.exception.ApiRequestException;
import com.example.ratemanagementsystem.model.Rate;
import com.example.ratemanagementsystem.model.Surcharge;
import com.example.ratemanagementsystem.repo.RateManagementSystemRepo;
import com.example.ratemanagementsystem.util.RateUtils;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class RateManagementSystemService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RateManagementSystemService.class);

	private RateManagementSystemRepo rateRepo;
	
	@Autowired
	public RateManagementSystemService(RateManagementSystemRepo rateRepo) {
		this.rateRepo = rateRepo;
	}
	
	public Rate addRate(Rate rate) throws ApiInternalErrorException{
		try {
			return rateRepo.save(rate);
		} catch (Exception e) {
			throw new ApiInternalErrorException("Internal server error. Please contact admin.");
		}
	}
	
	public List<Rate> findAllRates() throws ApiInternalErrorException {
		try {
			return rateRepo.findAll();
		} catch (Exception e) {
			throw new ApiInternalErrorException("Internal server error. Please contact admin.");
		}
	}
	
	public Rate updateRate(Rate rate) throws ApiInternalErrorException {
		try {
			return rateRepo.save(rate);
		} catch (Exception e) {
			throw new ApiInternalErrorException("Internal server error. Please contact admin.");
		}
	}
	
	public Rate findRateById(Long rateId) throws ApiRequestException {
		
		LOGGER.info("findRateById took input - {}", rateId);
		
		Rate rate = rateRepo.findByRateId(rateId)
				.orElseThrow(() -> new ApiRequestException("Rate by Id " + rateId + " not found in RMS"));

		LOGGER.info("findRateById produces output - {}", rate.toString());
		return rate;
	}
	

	public void deleteRate(Long rateId) throws ApiRequestException {
		
		LOGGER.info("deleteRate took input - {}", rateId);
		
		Rate rate = rateRepo.findByRateId(rateId).orElseThrow(() -> new ApiRequestException("Rate by Id " + rateId + " not found in RMS"));
		try{
			rateRepo.deleteById(rate.getRateId());
		} catch (Exception e) {
			throw new ApiRequestException(e.getMessage());
		}
		
		LOGGER.info("deleteRate deleted the rate successfully - {}", rateId);
	}
	
	
	@HystrixCommand(fallbackMethod = "getSurcharge_fallBack", commandKey = "findSurcharge")
	public Surcharge findSurcharge() throws ApiRequestException {
		LOGGER.info("Calling the underlying service");
		Surcharge result = null;
		try {
			RestTemplate restTemplate = new RestTemplate();
			result = restTemplate.getForObject(RateUtils.surchargeUri, Surcharge.class);

		} catch (RestClientException e) {
			LOGGER.error("******************&&&&&&&&&&&&&&&&------>>>>>>>>>>>>>>>>> RestClientException::  {}",
					e.getMessage());
			throw new ApiRequestException(e.getMessage());
		}
		LOGGER.info("Found Surcharge: {} and tax {} from underlying service", result.getSurcharge(), result.getTax());
		return result;
	}
	
	@SuppressWarnings("unused")
	private Surcharge getSurcharge_fallBack() {
		
		Surcharge surCharge = new Surcharge();
		surCharge.setError("CIRCUIT BREAKER ENABLED!!! No Response From external Service at this moment. " +
                " Service will be back shortly - " + new Date());
		return surCharge;
    }


}
