package com.example.ratemanagementsystem.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Surcharge implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long surcharge;
	
	private Long tax;
	
	@JsonProperty("error")
	String error;	

	public Long getSurcharge() {
		return surcharge;
	}

	public void setSurcharge(Long surcharge) {
		this.surcharge = surcharge;
	}

	public Long getTax() {
		return tax;
	}

	public void setTax(Long tax) {
		this.tax = tax;
	}
	
	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}

}
