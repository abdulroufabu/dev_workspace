package com.example.ratemanagementsystem.exception;

public class ApiInternalErrorException extends Exception {
	
	public ApiInternalErrorException(String message) {
		super(message);
	}
	
	public ApiInternalErrorException(String message, Throwable cause) {
		super(message, cause);
	}
}
