package com.example.ratemanagementsystem.controller;

import java.util.Date;
import java.util.List;

import javax.validation.constraints.Min;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.ratemanagementsystem.exception.InternalErrorException;
import com.example.ratemanagementsystem.exception.UserNotFoundException;
import com.example.ratemanagementsystem.model.Rate;
import com.example.ratemanagementsystem.model.RateDetail;
import com.example.ratemanagementsystem.service.RateManagementSystemService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@RequestMapping("logistics/v1/rate")
@Api(description  = "Set of endpoints for rate management system of a logistic company.")
public class RateManagementSystemController {
	
	private final RateManagementSystemService rmsService;

    public RateManagementSystemController(RateManagementSystemService rmsService) {
        this.rmsService = rmsService;
    }

    @ApiOperation("Returns the list of all rates.")
    @GetMapping("/all")
    public ResponseEntity<List<Rate>> findAllRates () {
        List<Rate> employees = rmsService.findAllRates();
        return new ResponseEntity<>(employees, HttpStatus.OK);
    }

    @ApiOperation("Returns the rate by an Id. 404 if does not exist.")
    @GetMapping("/find/{rateId}")
    @HystrixCommand(fallbackMethod = "findRateById_fallBack", ignoreExceptions = { UserNotFoundException.class })
    public ResponseEntity<RateDetail> findRateById (@PathVariable("rateId") Long rateId) throws UserNotFoundException {
    	RateDetail rateDetail = rmsService.findRateById(rateId);
        return new ResponseEntity<>(rateDetail, HttpStatus.OK);
    }

    @PostMapping("/add")
    public ResponseEntity<Rate> addRate(@RequestBody Rate employee) throws InternalErrorException {
        Rate newEmployee = rmsService.addRate(employee);
        return new ResponseEntity<>(newEmployee, HttpStatus.CREATED);
    }

    @PutMapping("/update")
    public ResponseEntity<Rate> updateRate(@RequestBody Rate employee) throws InternalErrorException {
        Rate updateEmployee = rmsService.updateRate(employee);
        return new ResponseEntity<>(updateEmployee, HttpStatus.OK);
    }

    @ApiOperation("Delete the rate by Id. 404 if does not exist.")
    @DeleteMapping("/delete/{rateId}")
    public ResponseEntity<?> deleteRate(@PathVariable("rateId") @Min(1) Long rateId) throws UserNotFoundException {
        rmsService.deleteRate(rateId);
        return ResponseEntity.ok().body("Rate deleted with success!");
    }
    
	@SuppressWarnings("unused")
	private ResponseEntity<RateDetail> findRateById_fallBack(Long rateId) {
		
		RateDetail rateDetail = new RateDetail();
		rateDetail.setError("CIRCUIT BREAKER ENABLED!!! No Response From FindRateById Service at this moment. " +
                " Service will be back shortly - " + new Date());
		return new ResponseEntity<>(rateDetail, HttpStatus.OK);
    }
}

