package com.example.ratemanagementsystem.exception;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR, reason = "Internal server error. Please contact admin")
public class InternalErrorException extends Exception {
	
	public InternalErrorException(String message) {
		super(message);
	}
}
