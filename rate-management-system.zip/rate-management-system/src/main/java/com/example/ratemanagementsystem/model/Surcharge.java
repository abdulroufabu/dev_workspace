package com.example.ratemanagementsystem.model;

import java.io.Serializable;

public class Surcharge implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long surcharge;
	
	private Long tax;

	public Long getSurcharge() {
		return surcharge;
	}

	public void setSurcharge(Long surcharge) {
		this.surcharge = surcharge;
	}

	public Long getTax() {
		return tax;
	}

	public void setTax(Long tax) {
		this.tax = tax;
	}

}
