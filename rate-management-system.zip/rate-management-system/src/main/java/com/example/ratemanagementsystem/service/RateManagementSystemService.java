package com.example.ratemanagementsystem.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.example.ratemanagementsystem.exception.InternalErrorException;
import com.example.ratemanagementsystem.exception.UserNotFoundException;
import com.example.ratemanagementsystem.model.Rate;
import com.example.ratemanagementsystem.model.RateDetail;
import com.example.ratemanagementsystem.model.Surcharge;
import com.example.ratemanagementsystem.repo.RateManagementSystemRepo;
import com.example.ratemanagementsystem.util.RateUtils;

@Service
public class RateManagementSystemService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(RateManagementSystemService.class);

	private RateManagementSystemRepo rateRepo;
	
	@Autowired
	public RateManagementSystemService(RateManagementSystemRepo rateRepo) {
		this.rateRepo = rateRepo;
	}
	
	public Rate addRate(Rate rate) throws InternalErrorException{
		try {
			return rateRepo.save(rate);
		} catch (Exception e) {
			throw new InternalErrorException("Internal server error. Please contact admin.");
		}
	}
	
	public List<Rate> findAllRates() {
		return rateRepo.findAll();
	}
	
	public Rate updateRate(Rate rate) throws InternalErrorException {
		try {
			return rateRepo.save(rate);
		} catch (Exception e) {
			throw new InternalErrorException("Internal server error. Please contact admin.");
		}
	}
	
	public RateDetail findRateById(Long rateId) throws UserNotFoundException {
		
		LOGGER.info("findRateById took input - {}", rateId);
		
		Rate rate = rateRepo.findByRateId(rateId)
				.orElseThrow(() -> new UserNotFoundException("Rate by Id " + rateId + " not found in RMS"));

		RateDetail rateDetail = null;
		try{
			RestTemplate restTemplate = new RestTemplate();
			Surcharge result = restTemplate.getForObject(RateUtils.surchargeUri, Surcharge.class);
	
			rateDetail = new RateDetail();
			rateDetail.setRate(rate);
			rateDetail.setSurcharge(result);
		} catch(RestClientException e){
			LOGGER.error("******************&&&&&&&&&&&&&&&&------>>>>>>>>>>>>>>>>> RestClientException::  {}", e.getMessage());
			throw new UsernameNotFoundException(e.getMessage());
		} catch (Exception e) {
			throw new UserNotFoundException(e.getMessage());
		}
		
		LOGGER.info("findRateById produces output - {}", rateDetail.toString());
		return rateDetail;
	}
	

	public void deleteRate(Long rateId) throws UserNotFoundException {
		
		LOGGER.info("deleteRate took input - {}", rateId);
		
		Rate rate = rateRepo.findByRateId(rateId).orElseThrow(() -> new UserNotFoundException("Rate by Id " + rateId + " not found in RMS"));
		
		try{
			rateRepo.deleteById(rate.getRateId());
		} catch (Exception e) {
			throw new UserNotFoundException(e.getMessage());
		}
		
		LOGGER.info("deleteRate deleted the rate successfully - {}", rateId);
	}
}
